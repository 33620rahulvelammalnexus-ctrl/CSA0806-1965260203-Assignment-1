import sys
import time
import code
from decimal import Decimal


# ---------- Part 1: interactive session (shows >>> prompts like the real interpreter) ----------
def session(lines):
    console = code.InteractiveConsole()
    for line in lines:
        print(">>> " + line)
        console.push(line)


print("=== Interactive session ===")
session([
    "type(10)",
    "type(10.0)",
    'type("10")',
    "type(True)",
    "type([10, 8.5])",
    "7 / 2",
    "7 // 2",
    "7 % 2",
    "-7 // 2",
    "0.1 + 0.2",
    "0.1 + 0.2 == 0.3",
    "from decimal import Decimal",
    'Decimal("0.1") + Decimal("0.2")',
    'Decimal("0.1") + Decimal("0.2") == Decimal("0.3")',
    "Decimal(0.1)",
    "round(0.1 + 0.2, 2) == 0.3",
])

print("""
Explanations:
type(10) is int, 10.0 is float, "10" is str, True is bool, [10, 8.5] is list.
7 / 2 = 3.5   : / is true division and always gives a float.
7 // 2 = 3    : // is floor division, it keeps only the whole part.
7 % 2 = 1     : % is the remainder after division.
-7 // 2 = -4  : surprising. Floor division rounds DOWN toward minus infinity
                (-3.5 goes down to -4), not toward zero (which would be -3).
0.1 + 0.2 == 0.3 is False : computers store floats in binary. 0.1 and 0.2 cannot
                be stored exactly (like 1/3 in decimal), so the sum is
                0.30000000000000004, which is not the stored value of 0.3.
Decimal(0.1) shows the long exact binary value that the float 0.1 really holds.
""")


# ---------- Part 2: Complete the Code ----------
payments = ["33.40"] * 1000 + ["0.10"] * 3


def total_float(items):
    total = 0.0
    for amount in items:
        total += float(amount)
    return total


def total_decimal(items):
    total = Decimal("0")                 # TODO 1
    for amount in items:
        total += Decimal(amount)         # exact: Decimal built from the string
    return total


print("=== Expected output ===")
print("float  :", total_float(payments))
print("Decimal:", total_decimal(payments))
print(0.1 + 0.2 == 0.3, Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))


# ---------- Change Decimal(amount) to Decimal(float(amount)) ----------
def total_decimal_from_float(items):
    total = Decimal("0")
    for amount in items:
        total += Decimal(float(amount))  # float is already inexact before Decimal sees it
    return total


print("\n=== Decimal(float(amount)) experiment ===")
print("Decimal(float(amount)):", total_decimal_from_float(payments))
print("Explanation: float('33.40') is already slightly wrong in binary. Decimal copies that")
print("wrong value exactly, so the total is no longer 33400.30. Always build Decimal from a STRING.")


# ---------- Alternatives ----------
def total_paise(items):
    """Integer paise: 33.40 rupees = 3340 paise. Whole numbers are exact."""
    total = 0
    for amount in items:
        total += round(float(amount) * 100)   # convert to paise once
    return total                              # divide by 100 only for display


def total_float_round(items):
    """float, but round to 2 places after every addition."""
    total = 0.0
    for amount in items:
        total = round(total + float(amount), 2)
    return total


print("\n=== Alternatives ===")
print("integer paise    :", total_paise(payments), "paise =", total_paise(payments) / 100, "rupees")
print("float + round()  :", total_float_round(payments))
print("Decimal          :", total_decimal(payments))

# time per addition (same 100000 additions for each method)
N = 100000
paise_list = [3340] * N
float_list = [33.40] * N
dec_list = [Decimal("33.40")] * N


def time_per_addition(add_one, items, start_value):
    start = time.perf_counter()
    total = start_value
    for x in items:
        total = add_one(total, x)
    return (time.perf_counter() - start) / len(items) * 1e9   # nanoseconds


t_int = time_per_addition(lambda t, x: t + x, paise_list, 0)
t_float = time_per_addition(lambda t, x: t + x, float_list, 0.0)
t_round = time_per_addition(lambda t, x: round(t + x, 2), float_list, 0.0)
t_dec = time_per_addition(lambda t, x: t + x, dec_list, Decimal("0"))

print("\n=== Time per addition and memory per value ===")
print("method             time/addition (ns)   memory per value (bytes)")
print("integer paise     ", round(t_int), "                ", sys.getsizeof(3340))
print("float              ", round(t_float), "                ", sys.getsizeof(33.40))
print("float + round()    ", round(t_round), "                ", sys.getsizeof(33.40))
print("Decimal            ", round(t_dec), "                ", sys.getsizeof(Decimal("33.40")))

# exactness for n payments of 33.40 (exact answer = n * 3340 paise)
print("\n=== Exact bank total check (n payments of Rs 33.40) ===")
print("n         exact      float_ok  float+round_ok  paise_ok  Decimal_ok")
for n in (10, 1000, 100000, 1000000):
    items = ["33.40"] * n
    exact = Decimal(n * 3340) / 100                 # exact answer from whole numbers
    f_ok = Decimal(str(total_float(items))) == exact
    r_ok = Decimal(str(total_float_round(items))) == exact
    p_ok = Decimal(total_paise(items)) / 100 == exact
    d_ok = total_decimal(items) == exact
    print(n, "  ", exact, "  ", f_ok, "  ", r_ok, "  ", p_ok, "  ", d_ok)