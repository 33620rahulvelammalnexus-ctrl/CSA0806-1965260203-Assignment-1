import time
from decimal import Decimal, ROUND_HALF_UP
BASE_RATE = Decimal("30.00")   # Rs per litre at standard quality
STD_FAT   = Decimal("3.5")     # standard fat %
STD_SNF   = Decimal("8.5")     # standard SNF %
STEP      = Decimal("0.1")     # rate changes in steps of 0.1 %
FAT_ADJ   = Decimal("0.40")    # Rs per 0.1 % fat above/below standard
SNF_ADJ   = Decimal("0.30")    # Rs per 0.1 % SNF above/below standard
FAT_MIN, FAT_MAX = Decimal("2.0"), Decimal("7.0")    # given in the problem
SNF_MIN, SNF_MAX = Decimal("6.0"), Decimal("10.0")   # assumption
MAX_LITRES = Decimal("500")    # assumption: catches typos like 1250 for 12.5
SHIFTS = ("M", "E")            # Morning / Evening
PAISA = Decimal("0.01")
def validate_entry(farmer_id, shift, litres, fat, snf):
    """Return a list of rule violations (empty list means valid)."""
    errors = []
    if not farmer_id.strip():
        errors.append("Farmer ID is empty")
    if shift not in SHIFTS:
        errors.append("Shift must be M or E")
    if not (0 < litres <= MAX_LITRES):
        errors.append("Litres must be > 0 and <= 500")
    if not (FAT_MIN <= fat <= FAT_MAX):
        errors.append("Fat must be between 2.0 and 7.0")
    if not (SNF_MIN <= snf <= SNF_MAX):
        errors.append("SNF must be between 6.0 and 10.0")
    return errors
def rate_per_litre(fat, snf):
    """Rate per litre in Rs, from fat % and SNF %."""
    fat_steps = (fat - STD_FAT) / STEP
    snf_steps = (snf - STD_SNF) / STEP
    return BASE_RATE + fat_steps * FAT_ADJ + snf_steps * SNF_ADJ
def entry_amount(litres, fat, snf):
    """Amount for one entry, rounded once (half-up) to the paisa."""
    return (litres * rate_per_litre(fat, snf)).quantize(PAISA, rounding=ROUND_HALF_UP)
def process_entries(raw_entries):
    """Validate and price all entries; return dict of ten-day totals."""
    totals = {}
    for fid, shift, l, f, s in raw_entries:
        litres, fat, snf = Decimal(l), Decimal(f), Decimal(s)
        errs = validate_entry(fid, shift, litres, fat, snf)
        if errs:
            print(f"REJECTED {fid} {shift}: {'; '.join(errs)}")
            continue
        rate = rate_per_litre(fat, snf)
        amt = entry_amount(litres, fat, snf)
        totals[fid] = totals.get(fid, Decimal("0.00")) + amt
        print(f"{fid} {shift}: {litres} L  rate Rs {rate:.2f}  amount Rs {amt}")
    return totals
raw_entries = [
    ("F001", "M", "12.5", "4.0", "8.8"),
    ("F001", "E", "10",   "3.5", "8.5"),
    ("F002", "M", "8.25", "3.2", "8.3"),
    ("F003", "M", "-5",   "3.5", "8.5"),   # invalid on purpose
]
print("=== Main design: list of tuples ===")
totals = process_entries(raw_entries)
print("\nTen-day totals")
for fid, t in totals.items():
    print(f"{fid}: Rs {t}")
print("\n=== Alternative design: separate variables ===")
litres1, fat1, snf1 = "12.5", "4.0", "8.8"
litres2, fat2, snf2 = "10",   "3.5", "8.5"
amt1 = entry_amount(Decimal(litres1), Decimal(fat1), Decimal(snf1))
amt2 = entry_amount(Decimal(litres2), Decimal(fat2), Decimal(snf2))
total_alt = amt1 + amt2          # for n entries: amt1 + amt2 + ... + amtn
print(f"F001 total (separate variables): Rs {total_alt}")
print("Matches main design:", total_alt == totals["F001"])
print("\n=== Timing: O(n) check ===")
for n in (300, 6000, 150000):
    data = [("F001", "M", "12.5", "4.0", "8.8")] * n
    t0 = time.perf_counter()
    for fid, sh, l, f, s in data:
        entry_amount(Decimal(l), Decimal(f), Decimal(s))
    print(f"n = {n:>6}: {time.perf_counter() - t0:.4f} s")
