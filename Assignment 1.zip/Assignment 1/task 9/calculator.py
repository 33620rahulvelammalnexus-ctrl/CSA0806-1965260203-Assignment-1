import time

# ---------- Rate card ----------
BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0      # allowed fat % (from Task 4)
MIN_SNF, MAX_SNF = 7.0, 10.0     # allowed SNF % (assumed, change to match your sheet)


# ---------- The calculator ----------
def to_number(text):
    """Return the number typed as text, or None if it is not a number."""
    text = text.strip()
    negative = text.startswith("-")
    if negative:
        text = text[1:]
    if text == "" or text.count(".") > 1 or not text.replace(".", "", 1).isdecimal():
        return None
    value = float(text)
    if negative:
        value = -value
    return value


def rate_per_litre(fat, snf):
    """Rate in Rs per litre, rounded to 2 decimals."""
    fat_steps = round((fat - STANDARD_FAT) / STEP)
    snf_steps = round((snf - STANDARD_SNF) / STEP)
    return round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)


def calculate(litres_text, fat_text, snf_text):
    """Return ("OK", payment) or ("INVALID", reason) for one entry typed as text."""
    litres = to_number(litres_text)
    fat = to_number(fat_text)
    snf = to_number(snf_text)
    if litres is None:
        return ("INVALID", "litres is not a number")
    if fat is None:
        return ("INVALID", "fat is not a number")
    if snf is None:
        return ("INVALID", "snf is not a number")
    if litres <= 0:
        return ("INVALID", "litres must be more than 0")
    if not MIN_FAT <= fat <= MAX_FAT:
        return ("INVALID", "fat out of range")
    if not MIN_SNF <= snf <= MAX_SNF:
        return ("INVALID", "snf out of range")
    return ("OK", round(litres * rate_per_litre(fat, snf), 2))


def total_for_entries(entries):
    """Total payment for a list of (litres, fat, snf) texts; invalid entries are skipped."""
    total = 0
    for litres_text, fat_text, snf_text in entries:
        status, value = calculate(litres_text, fat_text, snf_text)
        if status == "OK":
            total = total + value
    return round(total, 2)


def run_calculator():
    """Keyboard version: call run_calculator() to type entries by hand."""
    total = 0
    for day in range(1, 11):
        litres = input(f"Day {day} litres: ")
        fat = input("   fat %: ")
        snf = input("   snf %: ")
        status, value = calculate(litres, fat, snf)
        if status == "OK":
            total = total + value
            print(f"   payment {value:8.2f}")
        else:
            print("   invalid entry:", value, "- skipped")
    print(f"Ten-day total: {total:.2f}")


# ---------- Test cases: (name, (litres, fat, snf), expected) ----------
TESTS = [
    # normal entries in each direction
    ("fat above standard",        ("10", "4.2", "8.5"),  ("OK", 328.00)),
    ("fat below standard",        ("10", "3.1", "8.5"),  ("OK", 284.00)),
    ("snf above standard",        ("10", "3.5", "9.0"),  ("OK", 315.00)),
    ("snf below standard",        ("10", "3.5", "8.0"),  ("OK", 285.00)),
    ("fat and snf above",         ("8.5", "4.2", "8.7"), ("OK", 283.90)),
    ("fat and snf below",         ("12", "3.1", "8.3"),  ("OK", 333.60)),
    # boundary entries
    ("exactly 3.5 fat, 8.5 snf",  ("10", "3.5", "8.5"),  ("OK", 300.00)),
    ("lowest fat 2.0",            ("10", "2.0", "8.5"),  ("OK", 240.00)),
    ("highest fat 7.0",           ("10", "7.0", "8.5"),  ("OK", 440.00)),
    ("lowest snf 7.0",            ("10", "3.5", "7.0"),  ("OK", 255.00)),
    ("highest snf 10.0",          ("10", "3.5", "10.0"), ("OK", 345.00)),
    ("just below lowest fat 1.9", ("10", "1.9", "8.5"),  ("INVALID", "fat out of range")),
    ("just above highest fat 7.1", ("10", "7.1", "8.5"), ("INVALID", "fat out of range")),
    # invalid entries
    ("text litres",               ("abc", "3.5", "8.5"), ("INVALID", "litres is not a number")),
    ("text fat",                  ("10", "eight", "8.5"), ("INVALID", "fat is not a number")),
    ("comma decimal",             ("10", "3,5", "8.5"),  ("INVALID", "fat is not a number")),
    ("negative litres",           ("-5", "3.5", "8.5"),  ("INVALID", "litres must be more than 0")),
    ("zero litres",               ("0", "3.5", "8.5"),   ("INVALID", "litres must be more than 0")),
    ("fat out of range 9.5",      ("10", "9.5", "8.5"),  ("INVALID", "fat out of range")),
    ("snf out of range 12",       ("10", "3.5", "12"),   ("INVALID", "snf out of range")),
]

FIVE_ENTRIES = [("10", "3.5", "8.5"), ("8.5", "4.2", "8.7"), ("12", "3.1", "8.3"),
                ("9", "3.8", "8.6"), ("14", "3.6", "8.5")]
HAND_TOTAL = 1626.60       # 300.00 + 283.90 + 333.60 + 283.50 + 425.60


def run_tests(show=True):
    """Run every test with assert. Returns the number of failures."""
    if show:
        print(f"{'No':>2} {'Case':<27} {'Input':<20} {'Expected':<34} {'Actual':<34} Result")
    failures = 0
    for number, (name, entry, expected) in enumerate(TESTS, start=1):
        actual = calculate(*entry)
        try:
            assert actual == expected
            result = "PASS"
        except AssertionError:
            result = "FAIL"
            failures += 1
        if show:
            print(f"{number:>2} {name:<27} {str(entry):<20} {str(expected):<34} {str(actual):<34} {result}")
    # 5 entries with a total worked out by hand
    actual_total = total_for_entries(FIVE_ENTRIES)
    try:
        assert actual_total == HAND_TOTAL
        result = "PASS"
    except AssertionError:
        result = "FAIL"
        failures += 1
    if show:
        print(f"{'':>2} {'5-entry hand total':<27} {'5 entries':<20} {HAND_TOTAL:<34} {actual_total:<34} {result}")
    return failures


print("=== Test table (expected vs actual) ===")
failed = run_tests()
print("\nTests run:", len(TESTS) + 1, "| failures:", failed)
assert failed == 0, "some tests failed"
print("All tests passed.")

print("""
Hand calculation of the 5-entry total:
  10 L at 3.5 / 8.5 : rate 30.00           -> 300.00
  8.5 L at 4.2 / 8.7: 30 + 7*0.40 + 2*0.30 = 33.40 -> 283.90
  12 L at 3.1 / 8.3 : 30 - 4*0.40 - 2*0.30 = 27.80 -> 333.60
  9 L at 3.8 / 8.6  : 30 + 3*0.40 + 1*0.30 = 31.50 -> 283.50
  14 L at 3.6 / 8.5 : 30 + 1*0.40          = 30.40 -> 425.60
  Total = 300.00 + 283.90 + 333.60 + 283.50 + 425.60 = 1626.60""")

# ---------- Alternative: typing inputs by hand every time ----------
print("\n=== Alternative: manual testing vs assert-based testing ===")
count = len(TESTS) + 1
REPEATS = 1000
start = time.perf_counter()
for _ in range(REPEATS):
    run_tests(show=False)
auto_seconds = (time.perf_counter() - start) / REPEATS

SECONDS_PER_MANUAL_TEST = 20   # assumption: type 3 values, read the result, compare with the expected value
manual_seconds = count * SECONDS_PER_MANUAL_TEST
print("Manual process: run the program, type the 3 values for each case, read the output, compare it with the")
print("expected value in your head or on paper, repeat for every case, after EVERY change to the code.")
print(f"Tests: {count}")
print(f"Manual rerun   : about {manual_seconds} s ({manual_seconds / 60:.1f} min) assuming {SECONDS_PER_MANUAL_TEST} s per test (assumed figure)")
print(f"Assert rerun   : {auto_seconds * 1000:.3f} ms (measured, average of {REPEATS} runs)")
print(f"{'Changes':>8} | {'Manual total':>14} | {'Assert total':>14}")
for changes in (1, 10, 50):
    print(f"{changes:>8} | {changes * manual_seconds / 60:>11.1f} min | {changes * auto_seconds * 1000:>11.2f} ms")
print("""Both grow in a straight line with the number of tests T (time = T x time per test: O(T)).
The difference is the constant: the computer needs milliseconds per test, a person needs seconds, so adding
tests or changes makes manual testing cost more and more human time, while automatic testing stays almost free.
Manual testing can also miss a case, mistype an input or misread a result; assert tests repeat exactly.""")