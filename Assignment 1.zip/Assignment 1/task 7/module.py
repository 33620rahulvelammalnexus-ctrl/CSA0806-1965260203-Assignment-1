import sys
import time
import math
import types
from decimal import Decimal

# =====================================================================
# PART A: the module "milkrate" (this is exactly what goes in milkrate.py)
# =====================================================================
MILKRATE_SOURCE = '''"""Rate card of the village milk co-operative (used as a module)."""

BASE_RATE = 30.00       # Rs per litre for milk with 3.5 % fat and 8.5 % SNF
FAT_STEP_VALUE = 0.40   # Rs per litre for every 0.1 % of fat above or below 3.5
SNF_STEP_VALUE = 0.30   # Rs per litre for every 0.1 % of SNF above or below 8.5


def rate_per_litre(fat, snf):
    """Returns the price per litre, rounded to 2 decimals."""
    fat_steps = round((fat - 3.5) / 0.1)       # TODO 1: whole 0.1 % steps of fat
    snf_steps = round((snf - 8.5) / 0.1)       # TODO 1: whole 0.1 % steps of SNF
    rate = BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE
    return round(rate, 2)


def payout(litres, fat, snf):
    """Returns the amount payable to the farmer, rounded to 2 decimals."""
    return round(litres * rate_per_litre(fat, snf), 2)   # TODO 2


if __name__ == "__main__":
    for litres, fat, snf in [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]:
        rate, pay = rate_per_litre(fat, snf), payout(litres, fat, snf)
        print(f"{litres:5} L  fat {fat}  snf {snf}  rate {rate:6.2f}  pay {pay:8.2f}")
'''


def load_milkrate():
    """Build the module in memory and register it, so 'import milkrate' works."""
    module = types.ModuleType("milkrate")
    exec(MILKRATE_SOURCE, module.__dict__)
    sys.modules["milkrate"] = module


print("=== 1. Run the module directly (python milkrate.py) ===")
exec(MILKRATE_SOURCE, {"__name__": "__main__"})      # __name__ is '__main__', so the table prints

# =====================================================================
# PART B: the separate script that imports the module
# =====================================================================
load_milkrate()

print("\n=== 2. Three ways to import ===")
import milkrate
print("import milkrate             -> milkrate.payout(10, 4.0, 8.5) =", milkrate.payout(10, 4.0, 8.5))

from milkrate import payout
print("from milkrate import payout -> payout(10, 4.0, 8.5) =", payout(10, 4.0, 8.5))
try:
    exec("rate_per_litre(4.0, 8.5)", {})
except NameError as error:
    print("   only payout was copied, so rate_per_litre fails: NameError:", error)

import milkrate as mr
print("import milkrate as mr       -> mr.payout(10, 4.0, 8.5) =", mr.payout(10, 4.0, 8.5), "(short nickname)")

print("\n=== 3. Why the table is not printed on import ===")
print("Importing milkrate printed nothing. Inside the module, __name__ is:", repr(milkrate.__name__))
print("Run directly, __name__ is '__main__', so the table runs (Section 1).")
print("\nSame module WITHOUT the __name__ test, as if it were imported:")
no_guard = MILKRATE_SOURCE.replace('if __name__ == "__main__":', "if True:")
exec(no_guard, {"__name__": "milkrate_noguard"})
print("(the table was printed just by importing it - unwanted output)")

print("\n=== 4. Standard modules ===")
print("math.floor(-3.7) =", math.floor(-3.7), "| math.isclose(0.1 + 0.2, 0.3) =", math.isclose(0.1 + 0.2, 0.3))
print("Decimal(str(payout(10, 4.0, 8.5))) =", Decimal(str(payout(10, 4.0, 8.5))))

print("\n=== 5. Where Python looks for a module (sys.path) ===")
print("Search order: the script's folder first, then the standard library, then installed packages.")
for i, place in enumerate(sys.path[:3]):
    print("  sys.path[" + str(i) + "] =", repr(place))
try:
    import milkrates                  # wrong spelling
except ModuleNotFoundError as error:
    print("A module not on sys.path fails: ModuleNotFoundError:", error)
print("(Here milkrate is kept in sys.modules; with a real milkrate.py it must be in the script's folder.)")

print("\n=== 6. Alternative: copy the functions into every script ===")
k = 5
print("Scripts that need the rate card:", k)
print("A rate change (BASE_RATE 30.00 -> 31.00): copies need", k, "edits; the module needs 1 edit.")
stale = {"__name__": "copy"}
exec(MILKRATE_SOURCE, stale)                                              # copy nobody updated
fresh = {"__name__": "copy"}
exec(MILKRATE_SOURCE.replace("BASE_RATE = 30.00", "BASE_RATE = 31.00"), fresh)   # updated copy
print("Stale copy pays", stale["payout"](10, 4.0, 8.5), "but updated copy pays", fresh["payout"](10, 4.0, 8.5),
      "-> same farmer, different amounts: this is the risk of copies.")

print("\n=== 7. One-time cost of importing (sys.modules) ===")
print("'milkrate' in sys.modules:", "milkrate" in sys.modules)
start = time.perf_counter()
import milkrate                                  # already loaded: just a lookup
repeat_time = time.perf_counter() - start
del sys.modules["milkrate"]                      # forget it, to measure a fresh load
start = time.perf_counter()
load_milkrate()                                  # build it again
fresh_time = time.perf_counter() - start
print(f"Fresh load   : {fresh_time * 1e6:9.1f} microseconds")
print(f"Repeat import: {repeat_time * 1e6:9.1f} microseconds (found in sys.modules)")
print("The cost is paid once per program run, so it is O(1) however many payments are calculated.")
print("Memory: one module object is shared by every import.")