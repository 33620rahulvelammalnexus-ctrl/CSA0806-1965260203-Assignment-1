import time
import tracemalloc

# ---------- Constants ----------
BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0      # fat limits (from Task 4)
MIN_SNF, MAX_SNF = 7.0, 10.0     # SNF limits (assumed, change to match your sheet)

# =====================================================================
# 1. THE STEPS OF ALGORITHMIC PROBLEM SOLVING
# =====================================================================
print("=== 1. Steps of algorithmic problem solving ===")
print("""UNDERSTAND: input = 10 daily entries (litres, fat %, SNF %) for one farmer;
            output = payment for each day and the ten-day total; rule = rate from fat and SNF steps.
PLAN      : write pseudocode and a flowchart, then trace three entries by hand.
WRITE     : turn the pseudocode into Python, line by line (Section 4).
TEST      : run the entries traced by hand and check the program gives the same numbers.""")

# =====================================================================
# 2. PSEUDOCODE
# =====================================================================
print("\n=== 2. Pseudocode (conventional keywords; match them to your SIMATS standard sheet) ===")
print("""ALGORITHM TenDayPayment
  INPUT : ten entries, each with litres, fat, snf
  OUTPUT: payment for each valid day, and the ten-day total
  CONSTANTS: BASE_RATE = 30.00, FAT_STEP_VALUE = 0.40, SNF_STEP_VALUE = 0.30,
             STANDARD_FAT = 3.5, STANDARD_SNF = 8.5

  FUNCTION IsValidEntry(litres, fat, snf)
    IF litres > 0 AND MIN_FAT <= fat <= MAX_FAT AND MIN_SNF <= snf <= MAX_SNF THEN
      RETURN TRUE
    ELSE
      RETURN FALSE
    END IF
  END FUNCTION

  FUNCTION RatePerLitre(fat, snf)
    SET fatSteps <- ROUND((fat - STANDARD_FAT) / 0.1)
    SET snfSteps <- ROUND((snf - STANDARD_SNF) / 0.1)
    RETURN ROUND(BASE_RATE + fatSteps * FAT_STEP_VALUE + snfSteps * SNF_STEP_VALUE, 2)
  END FUNCTION

  BEGIN
    SET total <- 0
    FOR day <- 1 TO 10 DO
      READ litres, fat, snf
      IF IsValidEntry(litres, fat, snf) THEN
        SET payment <- ROUND(litres * RatePerLitre(fat, snf), 2)
        SET total   <- total + payment
        DISPLAY day, payment
      ELSE
        DISPLAY "Invalid entry on day", day, "- skipped"
      END IF
    END FOR
    DISPLAY "Ten-day total", total
  END
END ALGORITHM""")

# =====================================================================
# 3. FLOWCHART FOR VALIDATING ONE ENTRY (text form)
# =====================================================================
print("""
=== 3. Flowchart: validate one entry (text form) ===

      ( START )
          |
   [ READ litres, fat, snf ]
          |
   < litres > 0 ? > --No--+
          | Yes           |
   < 2.0 <= fat <= 7.0 ? >--No--+
          | Yes                 |
   < 7.0 <= snf <= 10.0 ? >--No-+
          | Yes                 |
   [ entry is VALID ]    [ entry is INVALID: show message ]
          |                     |
   [ calculate payment ]  [ skip this day ]
          |                     |
          +----------+----------+
                     |
                 ( END )
""")


# =====================================================================
# 4. PYTHON PROGRAM (matches the pseudocode line by line)
# =====================================================================
def is_valid_entry(litres, fat, snf):
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and MIN_SNF <= snf <= MAX_SNF


def rate_per_litre(fat, snf):
    fat_steps = round((fat - STANDARD_FAT) / STEP)
    snf_steps = round((snf - STANDARD_SNF) / STEP)
    return round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)


def ten_day_payment(entries, show=True):
    total = 0
    for day, (litres, fat, snf) in enumerate(entries, start=1):
        if is_valid_entry(litres, fat, snf):
            payment = round(litres * rate_per_litre(fat, snf), 2)
            total = total + payment
            if show:
                print(f"Day {day:2}: payment {payment:8.2f}")
        elif show:
            print(f"Invalid entry on day {day} - skipped")
    return round(total, 2)


# =====================================================================
# 5. HAND TRACE OF THREE ENTRIES
# =====================================================================
trace_entries = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]
print("=== 5. Hand trace (worked by hand first, then checked by the program) ===")
print("""Day 1: (10 L, 3.5, 8.5)  fatSteps = (3.5-3.5)/0.1 = 0   snfSteps = (8.5-8.5)/0.1 = 0
       rate = 30.00 + 0*0.40 + 0*0.30 = 30.00   payment = 10 * 30.00 = 300.00   total = 0 + 300.00 = 300.00
Day 2: (8.5 L, 4.2, 8.7) fatSteps = 0.7/0.1 = 7    snfSteps = 0.2/0.1 = 2
       rate = 30.00 + 7*0.40 + 2*0.30 = 33.40   payment = 8.5 * 33.40 = 283.90   total = 300.00 + 283.90 = 583.90
Day 3: (12 L, 3.1, 8.3)  fatSteps = -0.4/0.1 = -4  snfSteps = -0.2/0.1 = -2
       rate = 30.00 - 1.60 - 0.60 = 27.80       payment = 12 * 27.80 = 333.60   total = 583.90 + 333.60 = 917.50
""")
print("Day  litres  fat  snf  fatSteps snfSteps    rate   payment     total")
running = 0
for day, (litres, fat, snf) in enumerate(trace_entries, start=1):
    fs = round((fat - STANDARD_FAT) / STEP)
    ss = round((snf - STANDARD_SNF) / STEP)
    rate = rate_per_litre(fat, snf)
    pay = round(litres * rate, 2)
    running = round(running + pay, 2)
    print(f"{day:3} {litres:7} {fat:4} {snf:4} {fs:8} {ss:8} {rate:7.2f} {pay:9.2f} {running:9.2f}")
print("Program total:", ten_day_payment(trace_entries, show=False), "| hand total: 917.50 | match:",
      ten_day_payment(trace_entries, show=False) == 917.50)

print("\nValidation tests (flowchart paths):")
for entry in [(10, 3.5, 8.5), (0, 3.5, 8.5), (10, 1.5, 8.5), (10, 3.5, 12.0)]:
    print("  ", entry, "->", "VALID" if is_valid_entry(*entry) else "INVALID")

print("\nFull ten-day run (one invalid day included):")
ten_days = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3), (9, 3.8, 8.6), (0, 3.5, 8.5),
            (11.5, 4.5, 8.8), (7.5, 3.3, 8.3), (13, 3.9, 8.7), (10.5, 4.1, 8.9), (14, 3.6, 8.5)]
print("Ten-day total:", ten_day_payment(ten_days))


# =====================================================================
# 6. ALTERNATIVE: STORE EVERY ENTRY IN A LIST vs KEEP A RUNNING TOTAL
# =====================================================================
def total_with_list(entries):
    payments = []                                  # stores every payment: O(n) space
    for litres, fat, snf in entries:
        if is_valid_entry(litres, fat, snf):
            payments.append(round(litres * rate_per_litre(fat, snf), 2))
    return round(sum(payments), 2)


def total_running(entries):
    total = 0                                      # one number: O(1) space
    for litres, fat, snf in entries:
        if is_valid_entry(litres, fat, snf):
            total = total + round(litres * rate_per_litre(fat, snf), 2)
    return round(total, 2)


def make_entries(n):
    """Entries created one at a time (nothing is stored)."""
    for i in range(n):
        yield (10 + i % 5, 3.5 + (i % 10) * 0.1, 8.5 + (i % 7) * 0.1)


print("\n=== 6. Alternative: list of payments vs running total ===")
print("Same answer for the ten days?", total_with_list(ten_days) == total_running(ten_days) == ten_day_payment(ten_days, show=False))
print(f"{'n':>9} | {'list time(s)':>12} | {'running time(s)':>15} | {'list peak mem':>14} | {'running peak mem':>16} | same")
for n in (10, 1000, 100000, 1000000):
    results = []
    for func in (total_with_list, total_running):
        tracemalloc.start()
        start = time.perf_counter()
        answer = func(make_entries(n))
        elapsed = time.perf_counter() - start
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        results.append((answer, elapsed, peak))
    (a1, t1, m1), (a2, t2, m2) = results
    print(f"{n:>9} | {t1:>12.4f} | {t2:>15.4f} | {m1:>11} B | {m2:>13} B | {a1 == a2}")
print("""Both versions read each entry once: time O(n).
List version keeps n payments: space O(n). Running-total version keeps one number: space O(1).
Storing the entries is still necessary when you must: print a day-by-day report after the total, find the
highest or lowest day or the average, sort or search the entries, correct one day and recalculate, or
recalculate everything after a rate change. If only the final total is needed, use the running total.""")