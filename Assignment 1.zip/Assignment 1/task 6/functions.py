import time

# ---------- Constants (read-only by convention) ----------
BASE_RATE = 30.0
FAT_RATE = 0.40
SNF_RATE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1


# ---------- The functions ----------
def rate_per_litre(fat, snf):
    """Return the rate in Rs per litre for the given fat % and SNF %.

    Parameters: fat (float), snf (float). Returns: float.
    """
    fat_steps = round((fat - STANDARD_FAT) / STEP)     # local name
    snf_steps = round((snf - STANDARD_SNF) / STEP)     # local name
    return BASE_RATE + fat_steps * FAT_RATE + snf_steps * SNF_RATE


def payout(litres, fat, snf):
    """Return the amount in Rs for one entry of litres, fat % and SNF %.

    Parameters: litres, fat, snf (floats). Returns: float.
    """
    return litres * rate_per_litre(fat, snf)


def ten_day_total(entries):
    """Return the total amount in Rs for a list of (litres, fat, snf) entries.

    Parameters: entries (list of tuples). Returns: float.
    """
    total = 0.0
    for litres, fat, snf in entries:
        total += payout(litres, fat, snf)
    return total


def print_report(entries):
    """Print a table of the entries and the total. Returns nothing (None)."""
    print(f"{'Day':>4} {'Litres':>8} {'Fat%':>6} {'SNF%':>6} {'Rate':>8} {'Amount':>10}")
    for day, (litres, fat, snf) in enumerate(entries, start=1):
        print(f"{day:>4} {litres:8.1f} {fat:6.1f} {snf:6.1f} {rate_per_litre(fat, snf):8.2f} {payout(litres, fat, snf):10.2f}")
    print(f"{'Total':>4} {'':>8} {'':>6} {'':>6} {'':>8} {ten_day_total(entries):10.2f}")


entries = [(12.5, 4.2, 8.9), (10.0, 3.5, 8.5), (8.5, 3.1, 8.1), (15.0, 4.0, 9.0),
           (9.0, 3.8, 8.6), (11.5, 4.5, 8.8), (7.5, 3.3, 8.3), (13.0, 3.9, 8.7),
           (10.5, 4.1, 8.9), (14.0, 3.6, 8.5)]

print("=== 1. Functions, parameters and return values ===")
print("rate_per_litre(4.2, 8.9) =", round(rate_per_litre(4.2, 8.9), 2), "(hand: 30 + 7*0.40 + 4*0.30 = 34.0)")
print("payout(12.5, 4.2, 8.9)   =", round(payout(12.5, 4.2, 8.9), 2), "(hand: 12.5 * 34.0 = 425.0)")
print("ten_day_total(entries)   =", round(ten_day_total(entries), 2))
print()
print_report(entries)

print("\n=== 2. Returning a value is not the same as printing it ===")


def payout_prints(litres, fat, snf):
    print("Amount:", litres * rate_per_litre(fat, snf))   # shows it, but gives nothing back


result_print = payout_prints(10, 4.2, 8.9)
result_return = payout(10, 4.2, 8.9)
print("payout_prints returned:", result_print, "| payout returned:", result_return)
print("A printed value is only shown on the screen. A returned value can be stored, added up,")
print("tested and reused. A function that only prints returns None, so ten_day_total could not use it.")
try:
    print(result_print + 1)
except TypeError as error:
    print("Using the printed result in a sum fails: TypeError:", error)

print("\n=== 3. Local and global names ===")
print("Inside rate_per_litre, fat_steps and snf_steps are LOCAL: they exist only during the call.")
try:
    exec("print(fat_steps)")
except NameError as error:
    print("Outside the function: NameError:", error)
print("BASE_RATE is GLOBAL: a function may READ it without any special step.")


def broken_revision():
    BASE_RATE = BASE_RATE + 1      # assignment makes BASE_RATE local, but it has no value yet
    return BASE_RATE


try:
    broken_revision()
except UnboundLocalError as error:
    print("Trying to change it inside a function: UnboundLocalError:", error)
print("Assigning to a name inside a function makes it a new local name, so the global is not changed.")
print("The 'global' keyword can force a change, but then any call silently alters every later result.")
print("So rates are read inside functions and revised in ONE place: the constants at the top.")

print("\n=== 4. Docstrings ===")
for func in (rate_per_litre, payout, ten_day_total, print_report):
    print(func.__name__, "->", func.__doc__.strip().split("\n")[0])
print("A docstring is the first string in a function. help(function_name) and __doc__ show it.")


# ---------- Alternative: no functions, or lambdas ----------
print("\n=== 5. Alternative: one long script without functions ===")
script_lines = ["total = 0.0"]
for litres, fat, snf in entries:
    script_lines.append(f"total += {litres} * (BASE_RATE + round(({fat} - STANDARD_FAT) / STEP) * FAT_RATE"
                        f" + round(({snf} - STANDARD_SNF) / STEP) * SNF_RATE)")
script = "\n".join(script_lines)
namespace = dict(BASE_RATE=BASE_RATE, FAT_RATE=FAT_RATE, SNF_RATE=SNF_RATE,
                 STANDARD_FAT=STANDARD_FAT, STANDARD_SNF=STANDARD_SNF, STEP=STEP)
exec(script, namespace)
print("Straight-line script for", len(entries), "entries:", len(script_lines), "lines;",
      "the rate expression is typed", script.count("round((") // 2, "times (once per entry).")
print("Function version: the rate expression is written 1 time, whatever the number of entries.")
print("Same total?", round(namespace["total"], 2) == round(ten_day_total(entries), 2))

rate_lambda = lambda fat, snf: BASE_RATE + round((fat - STANDARD_FAT) / STEP) * FAT_RATE + round((snf - STANDARD_SNF) / STEP) * SNF_RATE
payout_lambda = lambda litres, fat, snf: litres * rate_lambda(fat, snf)
print("\nLambda version gives the same rate:", round(rate_lambda(4.2, 8.9), 2) == round(rate_per_litre(4.2, 8.9), 2))
print("But lambda has no docstring (__doc__ =", rate_lambda.__doc__, ") and its name is", rate_lambda.__name__,
      "so error messages are less clear,")
print("and it can hold only one expression, so it cannot hold the steps as separate named lines.")

# ---------- Function-call overhead ----------
print("\n=== 6. Does function-call overhead matter? (n entries, time per entry) ===")
print(f"{'n':>8} | {'inline loop':>12} | {'functions':>10} | {'lambdas':>9}   (nanoseconds per entry)")
for n in (1000, 10000, 100000):
    big = [(12.5, 4.2, 8.9)] * n

    start = time.perf_counter()
    total = 0.0
    for litres, fat, snf in big:
        total += litres * (BASE_RATE + round((fat - STANDARD_FAT) / STEP) * FAT_RATE
                           + round((snf - STANDARD_SNF) / STEP) * SNF_RATE)
    t_inline = (time.perf_counter() - start) / n * 1e9

    start = time.perf_counter()
    total_f = ten_day_total(big)
    t_func = (time.perf_counter() - start) / n * 1e9

    start = time.perf_counter()
    total_l = 0.0
    for litres, fat, snf in big:
        total_l += payout_lambda(litres, fat, snf)
    t_lambda = (time.perf_counter() - start) / n * 1e9

    same = round(total, 2) == round(total_f, 2) == round(total_l, 2)
    print(f"{n:>8} | {t_inline:>12.0f} | {t_func:>10.0f} | {t_lambda:>9.0f}   same totals: {same}")
print("""All three are O(n): one pass over the n entries, O(1) extra memory. Time per entry stays roughly flat as n grows (small runs are noisy).
Surprise: the function version is not consistently slower. Each call adds a small fixed cost, but code at the top of
a script reads names such as BASE_RATE and total as GLOBAL names, which is slower than the LOCAL names used
inside a function. So the two effects roughly cancel, and the function-call overhead is not noticeable.
Either way the difference is only tens of nanoseconds per entry, so clear, reusable functions are the better choice.""")