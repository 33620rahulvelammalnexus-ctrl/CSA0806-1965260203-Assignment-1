
"""
TASK 11 – RECOMMEND AND DEFEND THE FINAL DESIGN
Village Milk Co-operative Payment Calculator

Features:
1. Accurate milk payment calculation
2. Recommended data types and rounding
3. Rate revision support
4. Input validation
5. Automated experiments and test results
6. Performance measurements
7. District-union scale analysis
8. Alternative JSON rate-card analysis
"""

import json
import time
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


# --------------------------------------------------
# 1. FINAL DESIGN AND RATE CARD
# --------------------------------------------------

RATE_CARD = {
    "base_fat": Decimal("3.5"),
    "base_snf": Decimal("8.5"),
    "base_rate": Decimal("32.00"),
    "fat_step_rate": Decimal("0.45"),
    "bonus_threshold": Decimal("500"),
    "bonus_per_litre": Decimal("0.50")
}

# Monetary values are rounded to two decimal places.
# ROUND_HALF_UP is used for predictable financial rounding.


def money(value):
    return Decimal(str(value)).quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP
    )


# --------------------------------------------------
# 2. INPUT VALIDATION
# --------------------------------------------------

def validate_milk_data(farmer_id, litres, fat, snf):

    if not str(farmer_id).strip():
        raise ValueError("Farmer ID cannot be empty.")

    litres = Decimal(str(litres))
    fat = Decimal(str(fat))
    snf = Decimal(str(snf))

    if litres <= 0:
        raise ValueError("Litres must be greater than zero.")

    if not Decimal("2.0") <= fat <= Decimal("7.0"):
        raise ValueError("Fat must be between 2.0 and 7.0.")

    if snf <= 0:
        raise ValueError("SNF must be greater than zero.")

    return litres, fat, snf


# --------------------------------------------------
# 3. MILK RATE CALCULATION
# --------------------------------------------------

def calculate_rate(fat, snf, rate_card=RATE_CARD):

    fat = Decimal(str(fat))
    snf = Decimal(str(snf))

    fat_difference = fat - rate_card["base_fat"]

    rate = (
        rate_card["base_rate"]
        + fat_difference * rate_card["fat_step_rate"]
    )

    return money(rate)


# --------------------------------------------------
# 4. PAYMENT CALCULATION
# --------------------------------------------------

def calculate_payment(
    farmer_id,
    litres,
    fat,
    snf,
    rate_card=RATE_CARD
):

    litres, fat, snf = validate_milk_data(
        farmer_id, litres, fat, snf
    )

    rate = calculate_rate(fat, snf, rate_card)

    bonus = Decimal("0.00")

    if litres > rate_card["bonus_threshold"]:
        bonus = litres * rate_card["bonus_per_litre"]

    basic_amount = litres * rate

    total_amount = money(basic_amount + bonus)

    return {
        "farmer_id": str(farmer_id),
        "litres": litres,
        "fat": fat,
        "snf": snf,
        "rate": rate,
        "basic_amount": money(basic_amount),
        "bonus": money(bonus),
        "total_amount": total_amount
    }


# --------------------------------------------------
# 5. TEN-DAY PAYMENT TOTAL
# --------------------------------------------------

def calculate_ten_day_total(records):

    total = Decimal("0.00")

    for record in records:
        total += record["total_amount"]

    return money(total)


# --------------------------------------------------
# 6. RATE REVISION
# --------------------------------------------------

def revise_rate_card(
    current_rate_card,
    new_base_rate=None,
    new_fat_step_rate=None
):

    updated_card = current_rate_card.copy()

    if new_base_rate is not None:
        if Decimal(str(new_base_rate)) <= 0:
            raise ValueError("Base rate must be positive.")

        updated_card["base_rate"] = money(new_base_rate)

    if new_fat_step_rate is not None:
        if Decimal(str(new_fat_step_rate)) < 0:
            raise ValueError("Fat step rate cannot be negative.")

        updated_card["fat_step_rate"] = Decimal(
            str(new_fat_step_rate)
        )

    return updated_card


# --------------------------------------------------
# 7. ALTERNATIVE JSON RATE CARD
# --------------------------------------------------

def save_rate_card(rate_card, filename="rate_card.json"):

    json_data = {
        key: str(value)
        for key, value in rate_card.items()
    }

    with open(filename, "w", encoding="utf-8") as file:
        json.dump(json_data, file, indent=4)


def load_rate_card(filename="rate_card.json"):

    path = Path(filename)

    if not path.exists():
        save_rate_card(RATE_CARD, filename)

    with open(path, "r", encoding="utf-8") as file:
        data = json.load(file)

    return {
        key: Decimal(value)
        for key, value in data.items()
    }


# --------------------------------------------------
# 8. AUTOMATED EXPERIMENTS
# --------------------------------------------------

def run_experiments():

    print("\n========== EXPERIMENT RESULTS ==========")

    test_cases = [
        ("F001", "100", "3.5", "8.5"),
        ("F002", "600", "4.0", "8.7"),
        ("F003", "500", "5.0", "9.0"),
        ("F004", "250", "2.0", "8.5"),
        ("F005", "750", "7.0", "9.0")
    ]

    for test in test_cases:

        result = calculate_payment(*test)

        print("\nFarmer ID:", result["farmer_id"])
        print("Litres:", result["litres"])
        print("Fat:", result["fat"])
        print("SNF:", result["snf"])
        print("Rate per litre: Rs.", result["rate"])
        print("Basic amount: Rs.", result["basic_amount"])
        print("Bonus: Rs.", result["bonus"])
        print("Final payment: Rs.", result["total_amount"])

    # Verify expected results
    expected = [
        Decimal("3200.00"),
        Decimal("1980.00"),
        Decimal("3625.00"),
        Decimal("1837.50"),
        Decimal("5767.50")
    ]

    for test, expected_amount in zip(test_cases, expected):
        actual = calculate_payment(*test)["total_amount"]
        assert actual == expected_amount, (
            f"Test failed for {test[0]}"
        )

    print("\nAll five payment tests passed.")


# --------------------------------------------------
# 9. INVALID INPUT TESTING
# --------------------------------------------------

def test_invalid_inputs():

    print("\n========== VALIDATION TESTS ==========")

    invalid_cases = [
        ("F101", "-10", "3.5", "8.5"),
        ("F102", "100", "8.0", "8.5"),
        ("F103", "100", "1.0", "8.5"),
        ("", "100", "3.5", "8.5")
    ]

    for test in invalid_cases:

        try:
            calculate_payment(*test)
            print("FAILED:", test)

        except (ValueError, ArithmeticError):
            print("PASSED: Invalid input rejected:", test)


# --------------------------------------------------
# 10. RATE REVISION EXPERIMENT
# --------------------------------------------------

def test_rate_revision():

    print("\n========== RATE REVISION ==========")

    farmer = ("F200", "100", "3.5", "8.5")

    old_result = calculate_payment(*farmer)

    revised_card = revise_rate_card(
        RATE_CARD,
        new_base_rate="34.00",
        new_fat_step_rate="0.50"
    )

    new_result = calculate_payment(
        *farmer,
        rate_card=revised_card
    )

    print("Old base rate:", RATE_CARD["base_rate"])
    print("New base rate:", revised_card["base_rate"])

    print("Old payment:", old_result["total_amount"])
    print("New payment:", new_result["total_amount"])

    assert old_result["total_amount"] == Decimal("3200.00")
    assert new_result["total_amount"] == Decimal("3400.00")

    print("Rate revision test passed.")


# --------------------------------------------------
# 11. PERFORMANCE MEASUREMENT
# --------------------------------------------------

def performance_test(number_of_records=10000):

    print("\n========== PERFORMANCE TEST ==========")

    start = time.perf_counter()

    total = Decimal("0.00")

    for i in range(number_of_records):

        result = calculate_payment(
            f"F{i}",
            "100",
            "3.5",
            "8.5"
        )

        total += result["total_amount"]

    elapsed = time.perf_counter() - start

    print("Records processed:", number_of_records)
    print("Total payment:", money(total))
    print("Execution time:", round(elapsed, 6), "seconds")
    print(
        "Average time per record:",
        round(elapsed / number_of_records * 1000, 6),
        "milliseconds"
    )


# --------------------------------------------------
# 12. JSON START-UP TIME EXPERIMENT
# --------------------------------------------------

def json_performance_test():

    print("\n========== JSON RATE CARD TEST ==========")

    filename = "rate_card.json"

    save_rate_card(RATE_CARD, filename)

    start = time.perf_counter()

    loaded_card = load_rate_card(filename)

    elapsed = time.perf_counter() - start

    file_size = Path(filename).stat().st_size

    print("JSON rate card loaded successfully.")
    print("JSON file size:", file_size, "bytes")
    print("JSON loading time:", round(elapsed, 8), "seconds")

    assert loaded_card == RATE_CARD

    print("JSON rate card verification passed.")


# --------------------------------------------------
# 13. DISTRICT-UNION SCALE EXPERIMENT
# --------------------------------------------------

def district_union_test():

    print("\n========== DISTRICT-UNION SCALE TEST ==========")

    number_of_farmers = 100000

    start = time.perf_counter()

    total_payment = Decimal("0.00")

    for i in range(number_of_farmers):

        result = calculate_payment(
            f"DIST{i}",
            "100",
            "3.5",
            "8.5"
        )

        total_payment += result["total_amount"]

    elapsed = time.perf_counter() - start

    print("Farmers processed:", number_of_farmers)
    print("Total payment:", money(total_payment))
    print("Processing time:", round(elapsed, 4), "seconds")
    print("All records processed using the same calculation logic.")


# --------------------------------------------------
# 14. FINAL DESIGN RECOMMENDATION
# --------------------------------------------------

def final_recommendation():

    print("\n========== FINAL DESIGN RECOMMENDATION ==========")

    print("""
1. DATA TYPES AND ROUNDING:
   Decimal is recommended for money and milk rates because
   it avoids binary floating-point errors.
   ROUND_HALF_UP is used to round payments to two decimal places.

2. RATE REVISION:
   The rate card can be updated without changing the calculation
   functions. A JSON file is recommended for easier maintenance.

3. LIMITATIONS:
   The current design does not include database storage,
   user authentication, network security or automatic backups.
   SNF is validated but does not currently affect the rate formula.

4. DISTRICT-UNION SCALE:
   The same calculation logic can process many farmers.
   For large-scale use, database transactions, indexing,
   backups, access control and distributed processing may
   be required.

5. ALTERNATIVE JSON DESIGN:
   Reading t rate-card values takes O(t) time and O(t) space.
   Editing a JSON file avoids modifying and redistributing
   the entire program after every rate revision.
   The actual start-up cost should be measured on the target
   computer.

6. FINAL DECISION:
   Use Decimal for financial calculations, explicit validation,
   two-decimal ROUND_HALF_UP rounding, and an external JSON
   rate card for future revisions.
    """)


# --------------------------------------------------
# 15. MAIN PROGRAM
# --------------------------------------------------

def main():

    print("=" * 55)
    print(" VILLAGE MILK CO-OPERATIVE - TASK 11")
    print("=" * 55)

    run_experiments()

    test_invalid_inputs()

    test_rate_revision()

    performance_test()

    json_performance_test()

    district_union_test()

    final_recommendation()

    print("\n========== ALL TASK 11 OPERATIONS COMPLETED ==========")


if __name__ == "__main__":
    main()
