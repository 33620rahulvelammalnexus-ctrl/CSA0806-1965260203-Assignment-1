import random
import sys
import time
import tracemalloc
from decimal import Decimal, ROUND_HALF_UP

PAISE = Decimal("0.01")


# ---------- Rate (same as Task 7) ----------
def rate_per_litre(fat, snf):
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)
    return round(30.00 + fat_steps * 0.40 + snf_steps * 0.30, 2)


# ---------- Test data: the same entries are used for every method ----------
rng = random.Random(2024)
ALL = []
for _ in range(150000):
    litres = rng.randint(500, 2500) / 100     # 5.00 to 25.00 litres (2 decimals)
    fat = rng.randint(20, 70) / 10            # 2.0 to 7.0 %
    snf = rng.randint(70, 100) / 10           # 7.0 to 10.0 %
    ALL.append((f"{litres:.2f}", f"{fat:.1f}", f"{snf:.1f}"))   # typed text, as the clerk would give it


# ---------- Four ways to total the payments ----------
def float_each(entries):
    """float, rounding each payment to 2 decimals (what each farmer is paid)."""
    total = 0.0
    for litres, fat, snf in entries:
        total += round(float(litres) * rate_per_litre(float(fat), float(snf)), 2)
    return total


def float_total_only(entries):
    """float, adding unrounded payments and rounding only the final total."""
    total = 0.0
    for litres, fat, snf in entries:
        total += float(litres) * rate_per_litre(float(fat), float(snf))
    return round(total, 2)


def decimal_each(entries):
    """Decimal, each payment rounded to whole paise (the exact bank amount)."""
    total = Decimal("0")
    for litres, fat, snf in entries:
        rate = Decimal(str(rate_per_litre(float(fat), float(snf))))
        total += (Decimal(litres) * rate).quantize(PAISE, rounding=ROUND_HALF_UP)
    return total


def decimal_total_only(entries):
    """Decimal, adding exact unrounded payments and rounding only the total."""
    total = Decimal("0")
    for litres, fat, snf in entries:
        rate = Decimal(str(rate_per_litre(float(fat), float(snf))))
        total += Decimal(litres) * rate
    return total.quantize(PAISE, rounding=ROUND_HALF_UP)


def best_time(func, entries, repeats=3):
    best = None
    for _ in range(repeats):
        start = time.perf_counter()
        answer = func(entries)
        elapsed = time.perf_counter() - start
        if best is None or elapsed < best:
            best = elapsed
    return answer, best


print("=== 1. Expectation (written before running) ===")
print("""Expected: float totals will differ from Decimal by a tiny amount that grows with the number of payments,
because float cannot store most decimal fractions exactly. Decimal should be slower than float.
Rounding each payment should match the bank amount; rounding only the total may differ, because the
farmers are paid whole paise each.""")

print("\n=== 2. Observed totals (Rs) ===")
print(f"{'n':>7} | {'float each (raw)':>20} | {'Decimal each (bank)':>20} | {'float - bank':>14}")
results = {}
for n in (300, 6000, 150000):
    entries = ALL[:n]
    f_each, t_f = best_time(float_each, entries)
    d_each, t_d = best_time(decimal_each, entries)
    f_tot = float_total_only(entries)
    d_tot = decimal_total_only(entries)
    results[n] = (f_each, d_each, f_tot, d_tot, t_f, t_d)
    diff = Decimal(f_each) - d_each
    print(f"{n:>7} | {f_each!r:>20} | {str(d_each):>20} | {float(diff):>14.3e}")
print("Does float agree with Decimal after rounding the float total to 2 decimals?")
for n, (f_each, d_each, f_tot, d_tot, t_f, t_d) in results.items():
    print(f"  n = {n:>6}: round(float total, 2) = {round(f_each, 2)} | Decimal bank total = {d_each} | agree: {Decimal(str(round(f_each, 2))) == d_each}")

print("\n=== 3. Rounding each payment vs rounding only the total ===")
print(f"{'n':>7} | {'Decimal each (bank)':>20} | {'Decimal total only':>20} | {'difference':>11} | {'float total only':>17} | {'float - bank':>12}")
for n, (f_each, d_each, f_tot, d_tot, t_f, t_d) in results.items():
    print(f"{n:>7} | {str(d_each):>20} | {str(d_tot):>20} | {str(d_tot - d_each):>11} | {f_tot:>17} | {str(Decimal(str(f_tot)) - d_each):>12}")

print("\n=== 4. Time with time.perf_counter() (best of 3) ===")
print(f"{'n':>7} | {'float (s)':>10} | {'Decimal (s)':>11} | {'Decimal / float':>15} | {'float us/entry':>14} | {'Decimal us/entry':>16}")
for n, (f_each, d_each, f_tot, d_tot, t_f, t_d) in results.items():
    print(f"{n:>7} | {t_f:>10.4f} | {t_d:>11.4f} | {t_d / t_f:>14.1f}x | {t_f / n * 1e6:>14.2f} | {t_d / n * 1e6:>16.2f}")

print("\n=== 5. Finding the cause of the differences ===")
print(f"{'n':>7} | {'float raw error (no rounding)':>29} | {'half-paise payments':>19} | {'float rounds differently':>24} | {'difference they cause':>21}")
for n in (300, 6000, 150000):
    entries = ALL[:n]
    float_sum = 0.0
    exact_sum = Decimal("0")
    half_cases = 0
    mismatches = 0
    for litres, fat, snf in entries:
        rate = rate_per_litre(float(fat), float(snf))
        float_sum += float(litres) * rate
        exact = Decimal(litres) * Decimal(str(rate))
        exact_sum += exact
        if exact % PAISE == Decimal("0.005"):
            half_cases += 1
        if Decimal(str(round(float(litres) * rate, 2))) != exact.quantize(PAISE, rounding=ROUND_HALF_UP):
            mismatches += 1
    raw_error = Decimal(float_sum) - exact_sum
    print(f"{n:>7} | {float(raw_error):>29.3e} | {half_cases:>19} | {mismatches:>24} | {mismatches * 0.01:>21.2f}")

print("""
Expected vs observed:
- Expected: float and Decimal differ by a tiny amount. OBSERVED: only partly true. The pure float error (adding
  unrounded payments) IS tiny (about 1e-10 to 1e-6 rupees, first column). But the float-each total was off by
  Rs 0.14, Rs 2.85 and Rs 68.88, which is much larger than that error.
- Expected: Decimal slower than float. OBSERVED: yes, about 1.5 times slower per entry, and both grow in a
  straight line with n (O(n)).
- Expected: rounding each payment matches the bank amount, rounding only the total may differ. OBSERVED: yes, and
  the gap grew with n (Rs 0.19, Rs 2.83, Rs 70.87 in Decimal).

Reasons:
1. float stores numbers in binary, so 0.1 or 33.40 are stored with a tiny error. That error is why the raw
   float total is not exact, but it is only about a millionth of a rupee here.
2. The big difference comes from HALF-PAISE payments (a third decimal of exactly 5, such as 123.455). Decimal
   holds 123.455 exactly and ROUND_HALF_UP gives 123.46. float holds 123.455 as a binary number slightly above
   or below it, and round() follows that stored value, so many such payments go DOWN to 123.45. Each mismatch
   is one paisa, and the mismatches add up (second to fourth columns).
3. Each farmer is paid whole paise, so the correct bank amount is the sum of the rounded payments (Decimal each).
   Rounding only the total is lower by about Rs 0.0005 per entry because half-paise payments are rounded up for
   every farmer when paid but only once in the total, so it does not match the money actually paid out.
4. Decimal is slower because each operation handles exact digits and rounding rules; the cost per entry stays
   constant, so both methods are O(n).
Conclusion: for money use Decimal built from text, round each payment to paise, and add the rounded payments.""")

# ---------- Alternative: rate table (dictionary) ----------
print("=== 6. Alternative: rate table (dictionary) instead of recalculating ===")
N = 150000
data = [(float(a), float(b), float(c)) for a, b, c in ALL[:N]]


def with_recalculation(items):
    total = 0.0
    for litres, fat, snf in items:
        total += litres * rate_per_litre(fat, snf)
    return total


def build_table(items):
    table = {}
    for litres, fat, snf in items:
        if (fat, snf) not in table:
            table[(fat, snf)] = rate_per_litre(fat, snf)
    return table


def with_table(items, table):
    total = 0.0
    for litres, fat, snf in items:
        total += litres * table[(fat, snf)]
    return total


start = time.perf_counter()
table = build_table(data)
build_time = time.perf_counter() - start
k = len(table)

def best_of(func, *args):
    best = None
    for _ in range(3):
        start = time.perf_counter()
        func(*args)
        elapsed = time.perf_counter() - start
        if best is None or elapsed < best:
            best = elapsed
    return best


best_recalc = best_of(with_recalculation, data)
best_lookup = best_of(with_table, data, table)
same = with_recalculation(data) == with_table(data, table)

tracemalloc.start()
test_table = build_table(data)
table_bytes = tracemalloc.get_traced_memory()[0]
tracemalloc.stop()

print(f"Entries: {N} | different (fat, snf) pairs k = {k} | same total: {same}")
print(f"Recalculate every entry : {best_recalc:.4f} s  = {best_recalc / N * 1e9:.0f} ns per entry")
print(f"Dictionary lookup       : {best_lookup:.4f} s  = {best_lookup / N * 1e9:.0f} ns per entry (table built once in {build_time * 1000:.1f} ms)")
print(f"Extra space for the table: about {table_bytes} bytes for k = {k} pairs (about {table_bytes / k:.0f} bytes per pair)")
print(f"sys.getsizeof(table) = {sys.getsizeof(table)} bytes (the dictionary itself, without keys and values)")
print("""Recalculation: one subtraction, division, round and multiplication per entry; time O(1) per entry, O(n) in all.
Table: k calculations once, then O(1) per lookup; extra space O(k), and k is at most
(number of fat values) x (number of snf values), so it stays small however large n grows.
The table helps most when the rate calculation is expensive or the same pairs repeat many times.
Here the rate formula is cheap, so the saving is modest; the table also needs updating when a rate changes.""")