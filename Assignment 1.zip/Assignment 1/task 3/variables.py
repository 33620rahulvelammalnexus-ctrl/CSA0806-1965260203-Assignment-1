import sys
import time
import inspect

# ---------- Named constants (the single place to revise rates) ----------
BASE_RATE = 30.0       # Rs per litre at standard quality
FAT_RATE = 0.40        # Rs per litre for each 1% fat above/below standard
SNF_RATE = 0.30        # Rs per litre for each 1% SNF above/below standard
STANDARD_FAT = 3.5     # standard fat percentage
STANDARD_SNF = 8.5     # standard SNF percentage
MIN_FAT = 2.0          # lowest fat accepted (assumed limit, change to match your sheet)
MAX_FAT = 8.0          # highest fat accepted (assumed limit, change to match your sheet)


def rate_per_litre(fat, snf):
    return BASE_RATE + (fat - STANDARD_FAT) * FAT_RATE + (snf - STANDARD_SNF) * SNF_RATE


def payment(litres, fat, snf):
    return litres * rate_per_litre(fat, snf)


def is_valid_fat(fat):
    return MIN_FAT <= fat <= MAX_FAT


print("=== 1. Constants in use ===")
print("Rate per litre at 3.5% fat, 8.5% SNF:", rate_per_litre(3.5, 8.5))
print("Payment for 10 litres at 4.0% fat, 9.0% SNF: Rs", payment(10, 4.0, 9.0))
print("Is fat 9.0 valid?", is_valid_fat(9.0), "| Is fat 4.0 valid?", is_valid_fat(4.0))

# ---------- Naming rules ----------
print("""
=== 2. Naming rules and conventions ===
Rules (Python enforces these): a name may contain letters, digits and underscore,
cannot start with a digit, cannot contain spaces or symbols like - or $,
cannot be a keyword (if, for, class...), and is case-sensitive (Rate and rate differ).
Conventions (style, PEP 8): variables and functions use lower_case_with_underscores,
constants use UPPER_CASE_WITH_UNDERSCORES, names should say what the value means
(BASE_RATE, not b or x1).
""")

# ---------- No true constants ----------
print("=== 3. Python has no true constants ===")
print("Before:", BASE_RATE)
BASE_RATE = 99.0                      # Python allows this: no error
print("After BASE_RATE = 99.0:", BASE_RATE, "(no error, so UPPER_CASE is only a promise)")
BASE_RATE = 30.0                      # restore the real value
print("Restored:", BASE_RATE)
print("UPPER_CASE is a convention that tells other programmers: do not change this.")
print("Tools such as typing.Final can warn about changes, but Python itself does not stop them.")

# ---------- Dynamic typing ----------
print("\n=== 4. Dynamic typing ===")
value = 10
print("value =", value, "-> type:", type(value).__name__)
value = "ten"
print("value =", value, "-> type:", type(value).__name__)
print("The name 'value' is just a label. The TYPE belongs to the object, not to the name,")
print("so the same name can point to an int and later to a str without any error.")
try:
    print(10 + "ten")
except TypeError as error:
    print("But mixing types in one expression fails: TypeError:", error)

# ---------- Multiple assignment and swapping ----------
print("\n=== 5. Multiple assignment and swapping ===")
a, b = 5, 9
print("Before: a =", a, " b =", b)
a, b = b, a                           # the right side is evaluated first, then assigned
print("After a, b = b, a: a =", a, " b =", b)
x = y = 0
print("Chained assignment x = y = 0 gives x =", x, " y =", y)


# ---------- Alternative concept: magic numbers vs dictionary vs constants ----------
def rate_magic(fat, snf):
    return 30.0 + (fat - 3.5) * 0.40 + (snf - 8.5) * 0.30


def payment_magic(litres, fat, snf):
    return litres * (30.0 + (fat - 3.5) * 0.40 + (snf - 8.5) * 0.30)


def report_magic(fat, snf):
    return "Rate Rs " + str(30.0 + (fat - 3.5) * 0.40 + (snf - 8.5) * 0.30)


RATE_CARD = {"base": 30.0, "fat": 0.40, "snf": 0.30}


def rate_dict(fat, snf):
    return RATE_CARD["base"] + (fat - STANDARD_FAT) * RATE_CARD["fat"] + (snf - STANDARD_SNF) * RATE_CARD["snf"]


def report_constants(fat, snf):
    return "Rate Rs " + str(rate_per_litre(fat, snf))


print("\n=== 6. Alternatives: places to change when the base rate is revised ===")
magic_places = 0
for func in (rate_magic, payment_magic, report_magic):
    magic_places += inspect.getsource(func).count("30.0")
print("Magic numbers : base rate typed in", magic_places, "places (k =", magic_places, ")")
print("RATE_CARD dict: 1 place (the dictionary value)")
print("Constants     : 1 place (BASE_RATE)")

print("\nSame answers from all three methods?",
      rate_magic(4.0, 9.0) == rate_dict(4.0, 9.0) == rate_per_litre(4.0, 9.0))

N = 200000


def time_it(func):
    start = time.perf_counter()
    for _ in range(N):
        func(4.0, 9.0)
    return (time.perf_counter() - start) / N * 1e9      # nanoseconds per call


print("\n=== 7. Running time and memory ===")
print("method          time per call (ns)")
print("magic numbers  ", round(time_it(rate_magic)))
print("constants      ", round(time_it(rate_per_litre)))
print("RATE_CARD dict ", round(time_it(rate_dict)))
print("Memory: a float costs", sys.getsizeof(30.0), "bytes; the dict costs", sys.getsizeof(RATE_CARD),
      "bytes for 3 rates (values are still floats).")
print("Three constants cost about", 3 * sys.getsizeof(30.0), "bytes.")