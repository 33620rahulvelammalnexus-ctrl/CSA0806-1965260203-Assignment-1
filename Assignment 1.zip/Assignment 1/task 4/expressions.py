import math
import time

# ---------- Constants (from Task 3) ----------
BASE_RATE = 30.0
FAT_RATE = 0.40        # Rs per litre for each 0.1% fat step
SNF_RATE = 0.30        # Rs per litre for each 0.1% SNF step
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1
MIN_FAT = 2.0
MAX_FAT = 7.0


# ---------- The required expressions ----------
def fat_steps(fat):
    return round((fat - STANDARD_FAT) / STEP)


def snf_steps(snf):
    return round((snf - STANDARD_SNF) / STEP)


def rate_per_litre(fat, snf):
    return BASE_RATE + fat_steps(fat) * FAT_RATE + snf_steps(snf) * SNF_RATE


def amount(litres, fat, snf):
    return litres * rate_per_litre(fat, snf)


def show(expression):
    """Print an expression like an interactive session and its value."""
    print(">>> " + expression)
    print(eval(expression))


print("=== 1. The expressions in use ===")
print("fat_steps(4.2)         =", fat_steps(4.2))
print("snf_steps(8.9)         =", snf_steps(8.9))
print("rate_per_litre(4.2, 8.9) = Rs", round(rate_per_litre(4.2, 8.9), 2))
print("amount(10, 4.2, 8.9)     = Rs", round(amount(10, 4.2, 8.9), 2))
print("(Hand check: 30.0 + 7 * 0.40 + 4 * 0.30 = 34.0 per litre, 340.0 for 10 litres)")

print("\n=== 2. Precedence and associativity ===")
show("2 + 3 * 4")
show("(2 + 3) * 4")
show("-2 ** 2")
show("(-2) ** 2")
show("2 ** 3 ** 2")
show("10 - 4 - 3")
show("2 ** -1")
print("""Precedence (high to low): ** , unary minus, * / // %, + -, comparisons, not, and, or.
** binds tighter than unary minus on its LEFT, so -2 ** 2 is -(2 ** 2) = -4.
** is right-associative: 2 ** 3 ** 2 = 2 ** (3 ** 2) = 512.
- is left-associative: 10 - 4 - 3 = (10 - 4) - 3 = 3.
In the rate expression, * happens before +, so no brackets are needed around the products.""")

print("\n=== 3. Three (plus more) surprising results ===")
print("Surprise 1:")
show("(4.2 - 3.5) / 0.1")
print("Because 4.2, 3.5 and 0.1 are stored in binary with tiny errors, the answer is not exactly 7.")
print("(The last digits can differ slightly between Python versions, but it is never exactly 7.)")
print("round() gives the nearest whole number, so the step count is a clean 7.")
print("\nSurprise 2:")
show("(4.1 - 3.5) / 0.1")
show("int((4.1 - 3.5) / 0.1)")
print("The true answer is 6, but the float is just BELOW 6, and int() chops the decimals, so it gives 5.")
print("\nSurprise 3:")
show("-2 ** 2")
print("Many people expect 4. Python reads it as -(2 ** 2) = -4.")
print("\nSurprise 4:")
show("round(2.5)")
show("round(3.5)")
print("Python rounds exact halves to the nearest EVEN number (banker's rounding), so 2.5 becomes 2.")
print("\nSurprise 5:")
show("0.1 + 0.2 == 0.3")
print("Binary float error again: the sum is 0.30000000000000004.")

print("\n=== 4. round(), int() and math.floor() for negative values ===")
print("value    round   int   floor")
for v in (-3.7, -3.2, -3.5, 3.7):
    print(v, "   ", round(v), "  ", int(v), "  ", math.floor(v))
print("round: nearest whole number. int: cuts the decimals (toward zero). floor: always goes DOWN.")
print("For positive values int and floor always agree.")
print("For negatives, int(-3.7) = -3 but floor(-3.7) = -4 and round(-3.7) = -4.")

print("\n=== 5. Comparison chaining and Boolean operators ===")
fat = 4.2
show("2.0 <= fat <= 7.0")
show("2.0 <= fat and fat <= 7.0")
show("1 < 2 < 3")
show("1 < 3 < 2")
show("not 2.0 <= 9.0 <= 7.0")
show("False or True and False")
show("(False or True) and False")
print("""a <= x <= b means (a <= x) and (x <= b), x is evaluated once.
not is applied after comparisons, and before and, and before or.
and is evaluated before or: False or (True and False) = False.""")
for f in (1.9, 2.0, 4.2, 7.0, 7.1):
    print("fat", f, "valid:", MIN_FAT <= f <= MAX_FAT)

# ---------- Alternative: int() or floor() instead of round() ----------
def steps_round(x):
    return round(x)


def steps_int(x):
    return int(x)


def steps_floor(x):
    return math.floor(x)


print("\n=== 6. Alternative: int() or floor() instead of round() (snf at standard, so only fat matters) ===")
print("fat   raw value               round   int   floor   rate(round)  rate(int)  rate(floor)")
for fat in (4.2, 3.1, 4.1):
    raw = (fat - STANDARD_FAT) / STEP
    rates = []
    for func in (steps_round, steps_int, steps_floor):
        rates.append(round(BASE_RATE + func(raw) * FAT_RATE, 2))
    print(fat, " ", raw, "  ", steps_round(raw), "  ", steps_int(raw), "  ", steps_floor(raw), "  ", rates[0], "   ", rates[1], "   ", rates[2])
print("""Explanation:
fat 4.2: the raw value is just ABOVE 7, so round, int and floor all give 7. Same rate.
fat 3.1: the raw value is just ABOVE -4 (-3.99...). round gives -4 (correct). floor also gives -4 here,
         but int cuts toward zero and gives -3, so one step is lost and the farmer is overpaid.
fat 4.1: the raw value is just BELOW 6 (5.99...). int and floor both give 5, so one step is lost
         and the farmer is underpaid. Only round gives the correct 6.
So int() and floor() depend on which side of a whole number the float error lands. round() always
returns the intended step count, which is why it is used.
""")

N = 200000
raw = (4.2 - STANDARD_FAT) / STEP
print("method        time per call (ns)   space")
for name, func in (("round()", steps_round), ("int()", steps_int), ("math.floor()", steps_floor)):
    start = time.perf_counter()
    for _ in range(N):
        func(raw)
    print(name, "     ", round((time.perf_counter() - start) / N * 1e9), "                 O(1)")
print("All three are O(1) time (one operation) and O(1) space (one number); the differences are only nanoseconds.")