import time

# ---------- Constants and rate formula (from Tasks 3 and 4) ----------
BASE_RATE = 30.0
FAT_RATE = 0.40
SNF_RATE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP = 0.1


def rate_per_litre(fat, snf):
    return BASE_RATE + round((fat - STANDARD_FAT) / STEP) * FAT_RATE + round((snf - STANDARD_SNF) / STEP) * SNF_RATE


# ---------- Reading input ----------
# For the demo the clerk's typing is simulated with this list.
# To use the real keyboard, change the list below to SIMULATED = [] (get_text then calls input()).
SIMULATED = ["8,5", "eight", " 12.5 ",        # litres: two bad, then good
             "", "-3", "4,2", "4.2",           # fat: three bad, then good
             "8.5.5", "8.9"]                   # SNF: one bad, then good


def get_text(prompt):
    if SIMULATED:
        text = SIMULATED.pop(0)
        print(prompt + repr(text))        # show what the clerk typed
        return text
    return input(prompt)


def is_valid_number(text):
    """Method 1: check with string methods BEFORE converting."""
    text = text.strip()                        # remove spaces at both ends
    if text == "":
        return False
    if text.count(".") > 1:                    # more than one decimal point
        return False
    digits_only = text.replace(".", "", 1)     # remove the one allowed point
    return digits_only.isdecimal()             # only the characters 0-9 remain


def read_number(prompt):
    """Keep asking until the clerk types a valid non-negative number."""
    while True:
        text = get_text(prompt)
        if is_valid_number(text):
            return float(text)                 # input() gives a string; convert it
        print("   Invalid entry", repr(text), "- type a number such as 8.5")


print("=== 1. input() gives a string, so we convert ===")
text = "8.5"
print("type(text) =", type(text).__name__, "| type(float(text)) =", type(float(text)).__name__)
print("'8.5' + '1' =", "8.5" + "1", "(joined as text)  but  float('8.5') + 1 =", float("8.5") + 1)
print("int('8.5') fails because 8.5 is not a whole number:")
try:
    int("8.5")
except ValueError as error:
    print("   ValueError:", error)

print("\n=== 2. What happens with bad entries if we convert straight away ===")
for bad in ("8,5", "eight"):
    try:
        float(bad)
    except ValueError as error:
        print("float(" + repr(bad) + ") -> ValueError:", error)

print("\n=== 3. Reading with validation (simulated clerk entries) ===")
litres = read_number("Litres? ")
fat = read_number("Fat %? ")
snf = read_number("SNF %? ")
print("Accepted:", litres, fat, snf)

print("\n=== 4. Aligned results with f-strings ===")
entries = [(12.5, 4.2, 8.9), (100.0, 3.5, 8.5), (8.5, 3.1, 8.1), (250.25, 5.0, 9.2)]
print(f"{'Litres':>8} {'Fat%':>6} {'SNF%':>6} {'Rate':>8} {'Amount':>10}")
for litres, fat, snf in entries:
    rate = rate_per_litre(fat, snf)
    amount = litres * rate
    print(f"{litres:8.1f} {fat:6.1f} {snf:6.1f} {rate:8.2f} {amount:10.2f}")
print("Format {amount:10.2f} means: width 10 characters, 2 digits after the point, f for float.")
print("> aligns right (numbers look neat); text headings use {text:>8} the same way.")


# ---------- Alternative: try / except ----------
def read_with_try(text):
    """Method 2: just try to convert and catch the failure."""
    try:
        return float(text)
    except ValueError:
        return None


print("\n=== 5. Alternative: try/except ValueError - same inputs, both methods ===")
tests = ["8.5", "8,5", " 8.5 ", "eight", "", "-3", "8.5.5", "1e3", "8_5", "nan", "inf", "\u00b2"]
print(f"{'input':>10} | {'string check':>12} | {'try/except':>10}")
for t in tests:
    if is_valid_number(t):
        check = "accept"
    else:
        check = "reject"
    if read_with_try(t) is None:
        tried = "reject"
    else:
        tried = "accept"
    print(f"{t!r:>10} | {check:>12} | {tried:>10}")
print("""Reading the table:
"8,5" and "eight": both methods reject them (comma is not a decimal point, letters are not digits).
" 8.5 ": both accept. strip() removes the spaces in method 1; float() ignores spaces itself in method 2.
But try/except also accepts "1e3", "8_5" (read as 85), "nan", "inf" and "-3". These are not
sensible litres or fat values, so try/except needs extra range checks afterwards.
The string check is stricter and clearer about WHAT is allowed (digits and one point).
Its weakness: the rules are written by us, so a mistake can reject good input or accept bad input.""")
print("Note: '\\u00b2' (a superscript 2) passes .isdigit() but crashes float(); that is why we use .isdecimal().")
print("'\\u00b2'.isdigit() =", "\u00b2".isdigit(), "| '\\u00b2'.isdecimal() =", "\u00b2".isdecimal())

# ---------- Time per entry ----------
N = 200000


def time_it(func, text):
    start = time.perf_counter()
    for _ in range(N):
        func(text)
    return (time.perf_counter() - start) / N * 1e9


print("\n=== 6. Time per entry (nanoseconds) ===")
print(f"{'input':>8} | {'string check':>12} | {'try/except':>10}")
for t in ("8.5", "eight"):
    print(f"{t!r:>8} | {round(time_it(is_valid_number, t)):>12} | {round(time_it(read_with_try, t)):>10}")
print("""Both are O(1) per entry for a short input (O(L) for L characters, but entries are tiny).
The string check does several steps, so it is a little slower for a valid number.
try/except is fast when the entry is valid, but slower when it fails, because Python must create
and catch an exception. A clerk types slowly, so the difference does not matter.""")