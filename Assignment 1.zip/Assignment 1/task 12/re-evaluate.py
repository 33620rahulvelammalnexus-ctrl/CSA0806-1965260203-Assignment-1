
"""
TASK 12 – RE-EVALUATE AND ADAPT THE DESIGN
Village Milk Co-operative Payment Calculator

Decision: MODIFY the original design.

Sections:
A. Impact Analysis
B. Evaluation of Original Design
C. Adaptation and Implementation
D. Evidence-Based Defence
"""

from decimal import Decimal, ROUND_HALF_UP


# ==================================================
# 1. CONSTANTS AND SEASONAL RATE CARDS
# ==================================================

TWO_PLACES = Decimal("0.01")

SEASONAL_RATES = {
    "APRIL_JUNE": {
        "base_rate": Decimal("32.00"),
        "base_fat": Decimal("3.50"),
        "base_snf": Decimal("8.50"),
        "fat_step_rate": Decimal("0.45")
    },

    # Illustrative rate for other months.
    # Replace with the union's actual rate card.
    "OTHER_MONTHS": {
        "base_rate": Decimal("30.00"),
        "base_fat": Decimal("3.50"),
        "base_snf": Decimal("8.50"),
        "fat_step_rate": Decimal("0.40")
    }
}

BONUS_THRESHOLD = Decimal("500")
BONUS_PER_LITRE = Decimal("0.50")


# ==================================================
# 2. ROUNDING FUNCTION
# ==================================================

def round_money(value):
    return Decimal(str(value)).quantize(
        TWO_PLACES,
        rounding=ROUND_HALF_UP
    )


# ==================================================
# 3. INPUT VALIDATION
# ==================================================

def validate_input(farmer_id, litres, fat, snf):

    if not str(farmer_id).strip():
        raise ValueError("Farmer ID cannot be empty.")

    litres = Decimal(str(litres))
    fat = Decimal(str(fat))
    snf = Decimal(str(snf))

    if not litres.is_finite() or not fat.is_finite() or not snf.is_finite():
        raise ValueError("Inputs must be finite numbers.")

    if litres <= 0:
        raise ValueError("Litres must be greater than zero.")

    if not Decimal("2.00") <= fat <= Decimal("7.00"):
        raise ValueError("Fat must be between 2.00 and 7.00.")

    if snf <= 0:
        raise ValueError("SNF must be greater than zero.")

    return litres, fat, snf


# ==================================================
# 4. SELECT SEASONAL RATE CARD
# ==================================================

def get_rate_card(season):

    season = season.upper().strip()

    if season not in SEASONAL_RATES:
        raise ValueError("Invalid season selected.")

    return SEASONAL_RATES[season]


# ==================================================
# 5. CALCULATE MILK RATE
# ==================================================

def calculate_milk_rate(fat, season):

    rate_card = get_rate_card(season)

    fat = Decimal(str(fat))

    # One fat step = 0.10 fat units.
    fat_difference = fat - rate_card["base_fat"]

    fat_steps = fat_difference / Decimal("0.10")

    rate = (
        rate_card["base_rate"]
        + fat_steps * rate_card["fat_step_rate"]
    )

    return round_money(rate)


# ==================================================
# 6. CALCULATE TEN-DAY BONUS
# ==================================================

def calculate_bonus(total_litres):

    total_litres = Decimal(str(total_litres))

    if not total_litres.is_finite() or total_litres < 0:
        raise ValueError("Invalid ten-day milk quantity.")

    if total_litres > BONUS_THRESHOLD:
        return round_money(
            total_litres * BONUS_PER_LITRE
        )

    return Decimal("0.00")


# ==================================================
# 7. COMPLETE PAYMENT CALCULATION
# ==================================================

def calculate_payment(
    farmer_id,
    litres,
    fat,
    snf,
    season
):

    litres, fat, snf = validate_input(
        farmer_id, litres, fat, snf
    )

    rate_card = get_rate_card(season)

    rate = calculate_milk_rate(fat, season)

    basic_amount = round_money(litres * rate)

    bonus = calculate_bonus(litres)

    total_amount = round_money(
        basic_amount + bonus
    )

    fat_steps = (
        (fat - rate_card["base_fat"])
        / Decimal("0.10")
    )

    return {
        "farmer_id": str(farmer_id),
        "litres": litres,
        "fat": fat,
        "snf": snf,
        "season": season,
        "fat_steps": fat_steps,
        "milk_rate": rate,
        "basic_amount": basic_amount,
        "bonus": bonus,
        "total_amount": total_amount
    }


# ==================================================
# 8. DISPLAY PAYMENT DETAILS
# ==================================================

def display_result(result):

    print("\n----------------------------------------")
    print("        MILK PAYMENT DETAILS")
    print("----------------------------------------")

    print("Farmer ID      :", result["farmer_id"])
    print("Season         :", result["season"])
    print("Litres         :", result["litres"])
    print("Fat            :", result["fat"])
    print("SNF            :", result["snf"])
    print("Fat steps      :", result["fat_steps"])
    print("Milk rate      : Rs.", result["milk_rate"])
    print("Basic amount   : Rs.", result["basic_amount"])
    print("Ten-day bonus  : Rs.", result["bonus"])

    print("----------------------------------------")
    print("FINAL PAYMENT  : Rs.", result["total_amount"])
    print("----------------------------------------")


# ==================================================
# 9. SECTION A – IMPACT ANALYSIS
# ==================================================

def impact_analysis():

    print("\n========== SECTION A: IMPACT ANALYSIS ==========")

    print("""
CHANGES FROM THE ORIGINAL PROBLEM:

1. Automatic milk analysers now provide fat and SNF
   readings with two decimal places.

2. Seasonal rates are introduced from April to June.

3. Base rate is Rs. 32.00 during April-June.

4. Each 0.10 fat step is worth Rs. 0.45.

5. Farmers supplying more than 500 litres in ten days
   receive Rs. 0.50 bonus per litre.

AFFECTED COMPONENTS:

- Base rate constants
- Fat step rate
- Fat calculation expression
- Seasonal rate selection function
- Bonus calculation function
- Input validation and rounding

Decimal is retained to support precise financial
calculations and two-decimal analyser readings.
""")


# ==================================================
# 10. SECTION B – EVALUATION OF ORIGINAL DESIGN
# ==================================================

def evaluate_original_design():

    print("\n========== SECTION B: DESIGN EVALUATION ==========")

    print("""
The original design used a fixed rate and did not
support seasonal changes or ten-day bonuses.

The original Decimal data type is still appropriate.

However, the fixed constants and calculation functions
must be modified to support the new requirements.

WORKED EXAMPLES:

April-June:
Fat = 3.50
Rate = Rs. 32.00

Fat = 4.00
Fat steps = (4.00 - 3.50) / 0.10 = 5
Rate = 32.00 + (5 x 0.45) = Rs. 34.25

For 600 litres:
Basic amount = 600 x 34.25 = Rs. 20,550
Bonus = 600 x 0.50 = Rs. 300
Total = Rs. 20,850
""")


# ==================================================
# 11. SECTION C – ADAPTED DESIGN
# ==================================================

def adapted_design():

    print("\n========== SECTION C: ADAPTED DESIGN ==========")

    print("""
The original design is modified instead of completely
redesigned.

New functions:

1. get_rate_card() selects the seasonal rate.
2. calculate_milk_rate() calculates the fat-based rate.
3. calculate_bonus() calculates the ten-day bonus.
4. calculate_payment() combines all calculations.

Decimal is retained for accuracy.
Separate functions make testing and maintenance easier.
""")


# ==================================================
# 12. SECTION D – AUTOMATED PAYMENT TESTS
# ==================================================

def run_payment_tests():

    print("\n========== PAYMENT TEST RESULTS ==========")

    tests = [
        {
            "input": ("F001", "100", "3.50", "8.50", "APRIL_JUNE"),
            "rate": Decimal("32.00"),
            "bonus": Decimal("0.00"),
            "payment": Decimal("3200.00")
        },

        {
            "input": ("F002", "600", "4.00", "8.70", "APRIL_JUNE"),
            "rate": Decimal("34.25"),
            "bonus": Decimal("300.00"),
            "payment": Decimal("20850.00")
        },

        {
            "input": ("F003", "500", "3.75", "8.60", "APRIL_JUNE"),
            "rate": Decimal("33.13"),
            "bonus": Decimal("0.00"),
            "payment": Decimal("16565.00")
        },

        {
            "input": ("F004", "600", "4.00", "8.70", "OTHER_MONTHS"),
            "rate": Decimal("32.00"),
            "bonus": Decimal("300.00"),
            "payment": Decimal("19500.00")
        },

        {
            "input": ("F005", "500", "3.50", "8.50", "OTHER_MONTHS"),
            "rate": Decimal("30.00"),
            "bonus": Decimal("0.00"),
            "payment": Decimal("15000.00")
        }
    ]

    passed = 0

    for test in tests:

        result = calculate_payment(*test["input"])

        assert result["milk_rate"] == test["rate"]
        assert result["bonus"] == test["bonus"]
        assert result["total_amount"] == test["payment"]

        passed += 1

        print("\nTest", passed, ": PASSED")
        display_result(result)

    print("\nPayment tests passed:", passed, "/", len(tests))

    assert passed == len(tests)


# ==================================================
# 13. TWO-DECIMAL ANALYSER TEST
# ==================================================

def analyser_test():

    print("\n========== ANALYSER READING TEST ==========")

    readings = [
        "3.50",
        "3.55",
        "3.75",
        "4.25",
        "4.50"
    ]

    for fat in readings:

        rate = calculate_milk_rate(
            Decimal(fat),
            "APRIL_JUNE"
        )

        print(
            "Fat reading:", fat,
            "| Calculated rate: Rs.", rate
        )

    print("\nAnalyser tests completed successfully.")


# ==================================================
# 14. BONUS BOUNDARY TEST
# ==================================================

def bonus_test():

    print("\n========== TEN-DAY BONUS TEST ==========")

    test_litres = [
        "400",
        "500",
        "501",
        "600",
        "750"
    ]

    for litres in test_litres:

        bonus = calculate_bonus(litres)

        print(
            "Litres:", litres,
            "| Bonus: Rs.", bonus
        )

    assert calculate_bonus("500") == Decimal("0.00")
    assert calculate_bonus("501") == Decimal("250.50")
    assert calculate_bonus("600") == Decimal("300.00")

    print("\nAll bonus tests passed.")


# ==================================================
# 15. INVALID INPUT TEST
# ==================================================

def validation_test():

    print("\n========== INPUT VALIDATION TEST ==========")

    invalid_inputs = [
        ("F101", "-10", "3.50", "8.50", "APRIL_JUNE"),
        ("F102", "100", "8.00", "8.50", "APRIL_JUNE"),
        ("F103", "100", "3.50", "8.50", "WINTER"),
        ("", "100", "3.50", "8.50", "APRIL_JUNE")
    ]

    passed = 0

    for data in invalid_inputs:

        try:
            calculate_payment(*data)

            print("FAILED:", data)

        except (ValueError, ArithmeticError):
            passed += 1
            print("PASSED: Invalid input rejected.")

    assert passed == len(invalid_inputs)

    print("Validation tests passed:", passed, "/", len(invalid_inputs))


# ==================================================
# 16. FINAL EVIDENCE-BASED DEFENCE
# ==================================================

def final_defence():

    print("\n========== SECTION D: FINAL DEFENCE ==========")

    print("""
FINAL DESIGN DECISION: MODIFY

1. ACCURACY:
   Decimal supports accurate financial calculations.
   ROUND_HALF_UP provides consistent two-decimal rounding.

2. SEASONAL SUPPORT:
   Separate rate cards support different seasonal rates.

3. ANALYSER SUPPORT:
   Fat and SNF readings with two decimal places are accepted.

4. BONUS SUPPORT:
   Farmers supplying more than 500 litres receive
   Rs. 0.50 per litre as a ten-day bonus.

5. TEST EVIDENCE:
   Both seasonal rate cards were tested.
   Two-decimal fat readings were tested.
   The 500-litre bonus boundary was tested.
   Invalid inputs were rejected.

6. TRADE-OFFS:
   The modified design contains additional functions
   and constants, but it is easier to maintain and test.

7. LIMITATIONS:
   SNF is validated but does not affect the payment rate
   because an SNF pricing formula was not supplied.
   Database storage and automatic analyser connectivity
   are not implemented in this program.

CONCLUSION:
   Modifying the original design is the best decision.
   It retains the original calculation structure while
   supporting seasonal rates, analyser readings and bonuses.
""")


# ==================================================
# 17. MAIN FUNCTION
# ==================================================

def main():

    print("=" * 60)
    print(" VILLAGE MILK CO-OPERATIVE PAYMENT SYSTEM")
    print(" TASK 12 – RE-EVALUATE AND ADAPT THE DESIGN")
    print("=" * 60)

    impact_analysis()

    evaluate_original_design()

    adapted_design()

    run_payment_tests()

    analyser_test()

    bonus_test()

    validation_test()

    final_defence()

    print("\n" + "=" * 60)
    print(" ALL TASK 12 TESTS COMPLETED SUCCESSFULLY")
    print("=" * 60)


if __name__ == "__main__":
    main()
